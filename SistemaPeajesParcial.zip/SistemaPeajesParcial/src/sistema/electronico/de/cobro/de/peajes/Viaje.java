/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.electronico.de.cobro.de.peajes;

/**
 *
 * @author juani
 */
public class Viaje implements Comparable<Viaje> {
    private String nombrePasajero;
    private VehiculoTransporte vehiculo;
    private Pasaje pasaje;
    
    public Viaje(String nombrePasajero, VehiculoTransporte vehiculo, Pasaje pasaje){
        if( nombrePasajero == null || nombrePasajero.isEmpty())
            throw new IllegalArgumentException("El nombre del pasajero no puede estar vacio");
        
        this.nombrePasajero = nombrePasajero;
        this.vehiculo = vehiculo;
        this.pasaje = pasaje;
    }
    
    public double getCosto(){
        return pasaje.calcularCostoFinal();
    }
    public String getNombrePasajero() {
        return nombrePasajero;
    }
    
    @Override
    public int compareTo(Viaje otro){
        return Double.compare(this.getCosto(), otro.getCosto());
    }
    
    @Override
    public String toString(){
        return "Pasajero: " + nombrePasajero + ", Vehiculo: " + vehiculo + ", Costo: $" + getCosto();
    }
}
