/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.electronico.de.cobro.de.peajes;

/**
 *
 * @author juani
 */
public class Colectivo extends VehiculoTransporte{
    public Colectivo(String patente, int capacidad, String empresa){
        super(patente, capacidad, empresa);
    }
    
    @Override
    public double calcularCostoBase(){
        return 120.0;
    }
    
    @Override
    public String toString(){
        return "Colectivo --> " + super.toString();
    }
}
