/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.electronico.de.cobro.de.peajes;

/**
 *
 * @author juani
 */
public class PasajeEstudiante implements Pasaje{
    private VehiculoTransporte vehiculo;
    
    public PasajeEstudiante(VehiculoTransporte vehiculo){
        this.vehiculo = vehiculo;
    } 
    
    @Override
    public double calcularCostoFinal(){
        return vehiculo.calcularCostoBase() * 0.50;
    }
    
    @Override
    public String toString(){
        return "Pasaje Estudiante - $" + calcularCostoFinal();
    }
}
