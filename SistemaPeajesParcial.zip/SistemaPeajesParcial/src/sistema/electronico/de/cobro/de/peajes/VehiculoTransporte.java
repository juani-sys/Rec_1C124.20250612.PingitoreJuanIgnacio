/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.electronico.de.cobro.de.peajes;

/**
 *
 * @author juani
 */
public abstract class VehiculoTransporte {
    private String patente;
    private int capacidad;
    private String empresa;
    
    public VehiculoTransporte(String patente, int capacidad, String empresa){
        if (capacidad <= 0)
            throw new IllegalArgumentException("La capacidad no puede ser menor a 0.");
        
        this.patente = patente;
        this.capacidad = capacidad;
        this.empresa = empresa;
    }

    public String getPatente() {
        return patente;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }
    
    public abstract double calcularCostoBase();
    
    @Override
    public String toString(){
        return String.format("Patente: %s, Capacidad: %d, Empresa: %s", patente, capacidad, empresa);
    }
}
