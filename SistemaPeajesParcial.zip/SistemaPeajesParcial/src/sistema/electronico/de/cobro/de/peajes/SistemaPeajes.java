/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistema.electronico.de.cobro.de.peajes;
import java.util.*;

/**
 *
 * @author juani
 */
public class SistemaPeajes {
    private static List<Viaje> viajes = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
        
    public static void main(String[] args) {  
        int opcion;
        do {
            System.out.println("""
                               1. Registrar nuevo viaje
                               2. Mostrar todos los viajes
                               3. Ordenar viajes por costo
                               4. Ordenar viajes por nombre de pasajero 
                               5. Mostrar total recaudado
                               0. Salir...
                               """);
            opcion = scanner.nextInt();
            scanner.nextLine();
            switch (opcion){
                case 1 -> registrarViaje();
                case 2 -> mostrarViajes();
                case 3 -> ordenarPorCosto();
                case 4 -> ordenarPorNombre();
                case 5 -> mostrarRecaudacion();
            }
        } while (opcion != 0);
    }    
    
    private static void registrarViaje(){
        System.out.print("Nombre del pasajero: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Tipo de vehiculo(colectivo/tren/subte): ");
        String tipoVehiculo = scanner.nextLine().toLowerCase().trim();
        
        System.out.print("Patente: ");
        String patente = scanner.nextLine();
        
        System.out.print("Capacidad: ");
        int capacidad = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Empresa: ");
        String empresa = scanner.nextLine();
        
        VehiculoTransporte vehiculo = switch(tipoVehiculo){
            case "colectivo" -> new Colectivo(patente, capacidad, empresa);
            case "tren"      -> new Tren(patente, capacidad, empresa);
            case "subte"     -> new Subte(patente, capacidad, empresa);
            default          -> throw new IllegalArgumentException("Tipo de vehiculo invalido");
        };
        
        System.out.print("Tipo de pasaje(comun/estudiante/jubilado): ");
        String tipoPasaje = scanner.nextLine().toLowerCase().trim();
        
        Pasaje pasaje = switch(tipoPasaje){
            case "comun"      -> new PasajeComun(vehiculo);
            case "estudiante" -> new PasajeEstudiante(vehiculo);
            case "jubilado"   -> new PasajeJubilado(vehiculo);
            default           -> throw new IllegalArgumentException("Tipo de pasaje invalido");
        };
        
        viajes.add(new Viaje(nombre, vehiculo, pasaje));
        System.out.println("Viaje registrado correctamente");
    }
    
    private static void mostrarViajes(){
        if (viajes.isEmpty()){
            System.out.println("No hay viajes registrados");
        }else{
            viajes.forEach(System.out::println);
        }
    }
    
    private static void ordenarPorCosto(){
        viajes.sort(null);
        System.out.println("Viajes ordenados por costo");
    }
    
    private static void ordenarPorNombre(){
        viajes.sort(new ComparadorNombrePasajero());
        System.out.println("Viajes ordenados por nombre de pasajero");
    }
    
    private static void mostrarRecaudacion(){
        double total = viajes.stream().mapToDouble(Viaje::getCosto).sum();
        System.out.printf("Total recaudado: $%.2f%n", total);
    }
}
