/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema.electronico.de.cobro.de.peajes;

/**
 *
 * @author juani
 */
public class Subte extends VehiculoTransporte{
    public Subte(String patente, int capacidad, String empresa){
        super(patente, capacidad, empresa);
    }
    
    @Override
    public double calcularCostoBase(){
        return 100.0;
    }
    
    @Override
    public String toString(){
        return "Subte --> " + super.toString();
    }
}
